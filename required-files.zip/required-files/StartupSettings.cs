﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Diagnostics;
using System.Reflection;

public static class StartupSettings
{
    public static List<Type> controllerTypeList = [];

    private static bool _isDev;
    private static bool _useResponseCompression;
    private static bool _useSerilog;
    private static bool _writeVersion;

    public static void WebApplicationBuilderInitialize(this IServiceCollection services, string environmentName, IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        AppsettingsJsonFileSetup(environmentName, configurationManager);
        if (_useSerilog) SerilogSetup(configurationManager, hostBuilder);
        SwaggerSetup(services);

        if (_useResponseCompression) services.AddResponseCompression();
        if (_writeVersion)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string? assemblyVersion = assembly.GetName().Version?.ToString();
            string? fileVersion = FileVersionInfo.GetVersionInfo(assembly.Location).FileVersion;
            Log.Information($"Assembly Version: {assemblyVersion}");
            Log.Information($"File Version: {fileVersion}");
        }

    }
    public static void WebApplicationInitialize(this IApplicationBuilder app)
    {
        if (_isDev)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/All/swagger.json", "All");

                foreach (Type controller in controllerTypeList)
                {
                    string controllerName = controller.Name.Replace("Controller", "");
                    c.SwaggerEndpoint($"/swagger/{controllerName}/swagger.json", $"{controllerName}");
                }
            });
        }
        else // Production
        {
            //app.UseHttpsRedirection();
        }

        if (_useResponseCompression) app.UseResponseCompression();

    }

    #region Setups
    private static void AppsettingsJsonFileSetup(string environmentName, IConfigurationManager configurationManager)
    {
        #region Appsettings Json File Setup
        string envJsonFileName = $"appsettings.{environmentName}.json";
        configurationManager
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(envJsonFileName, optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
        #endregion

        #region Appsettings Variables
        _isDev = environmentName.Equals("Development");
        _useResponseCompression = bool.Parse(configurationManager["Params:UseResponseCompression"] ?? "false");
        _useSerilog = bool.Parse(configurationManager["Params:UseSerilog"] ?? "false");
        controllerTypeList = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(a => a.GetTypes())
            .Where(t => t.IsSubclassOf(typeof(ControllerBase)) && !t.IsAbstract)
            .ToList();
        _writeVersion = bool.Parse(configurationManager["Params:WriteVersion"] ?? "false");
        #endregion
    }
    private static void SerilogSetup(IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        Log.Logger = new LoggerConfiguration()
                    .ReadFrom.Configuration(configurationManager)
                    .WriteTo.Console(
                                    theme: Serilog.Sinks.SystemConsole.Themes.AnsiConsoleTheme.Literate,
                                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                    .CreateLogger();
        hostBuilder.UseSerilog();
    }
    private static void SwaggerSetup(IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("All", new OpenApiInfo
            {
                Title = "All Controllers",
                Version = "v1",
                Description = "All Controllers endpoints in one place."
            });

            foreach (Type controller in controllerTypeList)
            {
                string controllerName = controller.Name.Replace("Controller", "");
                c.SwaggerDoc(controllerName, new OpenApiInfo
                {
                    Title = $"{controllerName} Controller",
                    Version = "v1"
                });
            }

            c.DocInclusionPredicate((docName, apiDesc) =>
            {
                string? controllerName = apiDesc.ActionDescriptor.RouteValues["controller"];

                if (docName == "All") return true;
                return docName == controllerName;
            });

            c.CustomSchemaIds(type => type.FullName);
            c.DescribeAllParametersInCamelCase();
        });
    }
    #endregion
}