﻿using Microsoft.OpenApi.Models;
using Serilog;

public static class StartupSettings
{
    private static bool _isDev;
    private static bool _useResponseCompression;
    private static bool _useSerilog;
    public static void WebApplicationBuilderInitialize(this IServiceCollection services, string environmentName, IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        #region Appsettings Json File Setup
        string envJsonFileName = $"appsettings.{environmentName}.json";
        configurationManager
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(envJsonFileName, optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
        #endregion

        #region Appsettings Variables
        _isDev = environmentName.Equals("Development");
        _useResponseCompression = bool.Parse(configurationManager["Params:UseResponseCompression"] ?? "false");
        _useSerilog = bool.Parse(configurationManager["Params:UseSerilog"] ?? "false");
        #endregion

        #region Serilog
        if (_useSerilog)
        {
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configurationManager)
                .WriteTo.Console(
                                theme: Serilog.Sinks.SystemConsole.Themes.AnsiConsoleTheme.Literate,
                                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                .CreateLogger();
            hostBuilder.UseSerilog();
        }
        #endregion

        #region Swagger Settings
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "NX API Design",
                Version = "v1.1",
                Description = "Created by BK."
            });
            c.CustomSchemaIds(type => type.FullName);
            c.DescribeAllParametersInCamelCase(); //Parametrelerin daha net görünmesi ve düzenli olması için
        });
        #endregion

        if (_useResponseCompression) services.AddResponseCompression();

    }
    public static void WebApplicationInitialize(this IApplicationBuilder app)
    {
        if (_useResponseCompression) app.UseResponseCompression();

    }
}