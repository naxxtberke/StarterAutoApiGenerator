﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Serilog;

public static class StartupSettings
{
    private static bool _isDev;
    private static bool _useResponseCompression;
    private static bool _useSerilog;
    public static List<Type> controllers = [];
    public static void WebApplicationBuilderInitialize(this IServiceCollection services, string environmentName, IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        AppsettingsJsonFileSetup(environmentName, configurationManager);
        if (_useSerilog) SerilogSetup(configurationManager, hostBuilder);
        SwaggerSetup(services);

        if (_useResponseCompression) services.AddResponseCompression();

    }
    public static void WebApplicationInitialize(this IApplicationBuilder app)
    {
        if (_isDev)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/General/swagger.json", "General");

                foreach (var controller in StartupSettings.controllers)
                {
                    var controllerName = controller.Name.Replace("Controller", "");
                    c.SwaggerEndpoint($"/swagger/{controllerName}/swagger.json", $"{controllerName} API");
                }
            });
        }
        else // Production
        {
            //app.UseHttpsRedirection();
        }

        if (_useResponseCompression) app.UseResponseCompression();

    }

    #region Setups
    private static void AppsettingsJsonFileSetup(string environmentName, IConfigurationManager configurationManager)
    {
        #region Appsettings Json File Setup
        string envJsonFileName = $"appsettings.{environmentName}.json";
        configurationManager
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(envJsonFileName, optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
        #endregion

        #region Appsettings Variables
        _isDev = environmentName.Equals("Development");
        _useResponseCompression = bool.Parse(configurationManager["Params:UseResponseCompression"] ?? "false");
        _useSerilog = bool.Parse(configurationManager["Params:UseSerilog"] ?? "false");
        controllers = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(a => a.GetTypes())
            .Where(t => t.IsSubclassOf(typeof(ControllerBase)) && !t.IsAbstract)
            .ToList();
        #endregion
    }
    private static void SerilogSetup(IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        Log.Logger = new LoggerConfiguration()
                    .ReadFrom.Configuration(configurationManager)
                    .WriteTo.Console(
                                    theme: Serilog.Sinks.SystemConsole.Themes.AnsiConsoleTheme.Literate,
                                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                    .CreateLogger();
        hostBuilder.UseSerilog();
    }
    private static void SwaggerSetup(IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("General", new OpenApiInfo
            {
                Title = "General",
                Version = "v1",
                Description = "All API endpoints in one place."
            });

            foreach (Type controller in controllers)
            {
                string controllerName = controller.Name.Replace("Controller", "");
                c.SwaggerDoc(controllerName, new OpenApiInfo
                {
                    Title = $"{controllerName} API",
                    Version = "v1"
                });
            }

            c.DocInclusionPredicate((docName, apiDesc) =>
            {
                string? controllerName = apiDesc.ActionDescriptor.RouteValues["controller"];

                if (docName == "General")
                    return true;

                return docName == controllerName;
            });

            c.CustomSchemaIds(type => type.FullName);
            c.DescribeAllParametersInCamelCase();
        });
    }
    #endregion
}