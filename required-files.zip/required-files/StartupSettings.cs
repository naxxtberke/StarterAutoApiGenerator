﻿using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Linq;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Dynamic;

public static class StartupSettings
{
    [AllowNull]
    public static dynamic appSettings { get; set; }
    public static bool envIsDev = false;
    public static void BuilderSettingsSetup(this IServiceCollection services, string environmentName, IConfigurationManager configurationManager, IHostBuilder hostBuilder)
    {
        #region Appsettings Json File Setup
        string envJsonFileName = $"appsettings.{environmentName}.json";
        configurationManager
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(envJsonFileName, optional: false, reloadOnChange: true);

        SetAppsettingsJsonFile(envJsonFileName);
        #endregion

        #region Serilog
        Log.Logger = new LoggerConfiguration()
                        .ReadFrom.Configuration(configurationManager)
                        .WriteTo.Console(
            theme: Serilog.Sinks.SystemConsole.Themes.AnsiConsoleTheme.Literate,
            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
                        .CreateLogger();
        hostBuilder.UseSerilog();
        #endregion

        #region Swagger Settings
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "NX API Design",
                Version = "v1.1",
                Description = "Created by BK."
            });
            c.CustomSchemaIds(type => type.FullName);
            c.DescribeAllParametersInCamelCase(); //Parametrelerin daha net görünmesi ve düzenli olması için
        });
        #endregion

        #region Params Settings

        if (appSettings.Params.UseResponseCompression) services.AddResponseCompression();

        #endregion
    }
    public static void AppSettingsSetup(this IApplicationBuilder app)
    {
        #region Params Settings

        if (appSettings.Params.UseResponseCompression) app.UseResponseCompression();

        #endregion

    }
    private static void SetAppsettingsJsonFile(string envJsonFileName)
    {
        string basePath = AppDomain.CurrentDomain.BaseDirectory;
        string baseEnvJsonFilePath = Path.Combine(basePath, "appsettings.json");
        string customEnvJsonFilePath = Path.Combine(basePath, envJsonFileName);

        // Temel ve ortam JSON dosyalarını JObject olarak yükle
        JObject baseSettings = JObject.Parse(File.ReadAllText(baseEnvJsonFilePath));
        JObject envSettings = File.Exists(customEnvJsonFilePath)
                              ? JObject.Parse(File.ReadAllText(customEnvJsonFilePath))
                              : [];

        // Ortam ayarlarını temel ayarların üzerine yazdırarak birleştirme işlemi
        MergeJson(baseSettings, envSettings);

        // Dinamik olarak _appSettings'e atama
        appSettings = baseSettings.ToObject<ExpandoObject>();
    }
    private static void MergeJson(JObject target, JObject source)
    {
        foreach (JProperty property in source.Properties())
        {
            if (target[property.Name] is JObject targetChild && property.Value is JObject sourceChild)
            {
                // İç içe JSON nesneleri varsa, bunları da birleşik olarak güncelle
                MergeJson(targetChild, sourceChild);
            }
            else
            {
                // Aksi halde doğrudan kaynak değeri hedefe yazdır
                target[property.Name] = property.Value;
            }
        }
    }
}