
WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

builder.Services.WebApplicationBuilderInitialize(builder.Environment.EnvironmentName, builder.Configuration, builder.Host);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

WebApplication app = builder.Build();

app.WebApplicationInitialize();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else if (app.Environment.IsProduction())
{
    //app.UseHttpsRedirection();
}

app.MapControllers();

app.Run();