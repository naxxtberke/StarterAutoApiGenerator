
WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

builder.Services.WebApplicationBuilderInitialize(builder.Environment.EnvironmentName, builder.Configuration, builder.Host);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

WebApplication app = builder.Build();

app.WebApplicationInitialize();

app.MapControllers();

app.Run();