
WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

builder.Services.BuilderSettingsSetup(builder.Environment.EnvironmentName, builder.Configuration, builder.Host);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

WebApplication app = builder.Build();

app.AppSettingsSetup();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else if (app.Environment.IsProduction())
{
    app.UseHttpsRedirection();
}

app.MapControllers();

app.Run();